from main import kyber

def encrypt(str):
    return kyber(str);